// ===== Ramayana: Battle of Lanka — Game Logic =====

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const GROUND_Y = 400;

// ---- Level configuration (story-driven progression) ----
const LEVELS = [
  {
    name: "Ayodhya",
    bg: "#87CEEB",
    ground: "#7CFC8B",
    objective: "Learn to move (←/→) and shoot (Space). Defeat the training targets.",
    story: [
      "Prince Rama prepares to leave Ayodhya on a long journey.",
      "Before setting out, he trains with his bow.",
    ],
    waveCount: 3,
    enemyHealth: 20,
    enemySpeed: 1.0,
    spawnGap: 100,
  },
  {
    name: "Forest",
    bg: "#3a6b4a",
    ground: "#1f3a26",
    objective: "The forest path is guarded. Clear the way forward.",
    story: [
      "The road leads through a dense, unfamiliar forest.",
      "Rama and Lakshmana stay alert as they travel.",
    ],
    waveCount: 5,
    enemyHealth: 30,
    enemySpeed: 1.4,
    spawnGap: 80,
  },
  {
    name: "Kishkindha",
    bg: "#caa25e",
    ground: "#8b6b3d",
    objective: "Fight alongside your allies. Press H to call on Hanuman!",
    story: [
      "In Kishkindha, the Vanara king pledges his allies to the cause.",
      "Hanuman lends his strength — press H to unleash his ability.",
    ],
    waveCount: 6,
    enemyHealth: 35,
    enemySpeed: 1.6,
    spawnGap: 65,
    allyAbility: true,
  },
  {
    name: "Lanka",
    bg: "#7a3a2e",
    ground: "#4a1a1a",
    objective: "Push through Lanka's defenses toward the final confrontation.",
    story: [
      "Rama and his allies reach the shores of Lanka.",
      "Its defenders stand ready. The final battle draws near.",
    ],
    waveCount: 8,
    enemyHealth: 45,
    enemySpeed: 1.8,
    spawnGap: 55,
    allyAbility: true,
  },
  {
    name: "Battle of Lanka — Final Encounter",
    bg: "#2c1414",
    ground: "#1a0d0d",
    objective: "Learn the encounter's patterns. Stand firm and prevail.",
    story: [
      "The final confrontation begins.",
      "This is a story-driven encounter with multiple phases — watch and adapt.",
    ],
    isBoss: true,
    allyAbility: true,
  },
];

// ---- Game state ----
let state = "menu"; // menu, story, playing, paused, levelComplete, gameOver, victory
let currentLevel = 0;
let score = 0;
let frame = 0;

const player = {
  x: 60, y: GROUND_Y - 70, width: 50, height: 70,
  speed: 4, health: 100, maxHealth: 100,
  shootCooldown: 0, hitCooldown: 0,
};

let arrows = [];
let enemies = [];
let powerUps = [];
let boss = null;
let allyCooldown = 0;

let waveRemainingToSpawn = 0;
let spawnTimer = 0;

const keys = {};

// ---- Helpers ----
function collision(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

// ---- UI wiring ----
const el = (id) => document.getElementById(id);
const screens = {
  menu: el("menuScreen"),
  story: el("storyScreen"),
  levelComplete: el("levelCompleteScreen"),
  paused: el("pauseScreen"),
  gameOver: el("gameOverScreen"),
  victory: el("victoryScreen"),
};
function showOnly(name) {
  Object.values(screens).forEach((s) => s.classList.add("hidden"));
  if (screens[name]) screens[name].classList.remove("hidden");
}

el("startBtn").addEventListener("click", () => {
  currentLevel = 0;
  score = 0;
  player.health = player.maxHealth;
  beginStory();
});
el("continueBtn").addEventListener("click", () => {
  showOnly(null);
  initLevel(currentLevel);
  state = "playing";
});
el("nextLevelBtn").addEventListener("click", () => {
  currentLevel++;
  if (currentLevel >= LEVELS.length) {
    finishGame();
  } else {
    beginStory();
  }
});
el("resumeBtn").addEventListener("click", () => {
  showOnly(null);
  state = "playing";
});
el("retryBtn").addEventListener("click", () => {
  player.health = player.maxHealth;
  showOnly(null);
  initLevel(currentLevel);
  state = "playing";
});
el("restartBtn").addEventListener("click", () => {
  currentLevel = 0;
  score = 0;
  player.health = player.maxHealth;
  beginStory();
});

function beginStory() {
  const lvl = LEVELS[currentLevel];
  el("storyTitle").textContent = lvl.name;
  el("storyText").textContent = lvl.story.join("  ");
  showOnly("story");
  state = "story";
}

function finishGame() {
  el("finalScoreText").textContent = "Final Score: " + score;
  showOnly("victory");
  state = "victory";
}

// ---- Level setup ----
function initLevel(index) {
  const lvl = LEVELS[index];
  player.x = 60;
  player.y = GROUND_Y - player.height;
  arrows = [];
  enemies = [];
  powerUps = [];
  boss = null;
  frame = 0;
  spawnTimer = 0;
  allyCooldown = 0;
  el("levelText").textContent = lvl.name;
  el("objectiveBox").textContent = "Objective: " + lvl.objective;

  if (lvl.isBoss) {
    boss = {
      x: 700, y: GROUND_Y - 130, width: 90, height: 130,
      health: 600, maxHealth: 600, phase: 1,
      speed: 1, dir: -1, hitCooldown: 0, spawnFlagPhase2: false, spawnFlagPhase3: false,
    };
    el("bossBarWrap").classList.remove("hidden");
    updateBossBar();
  } else {
    waveRemainingToSpawn = lvl.waveCount;
    el("bossBarWrap").classList.add("hidden");
  }
}

function spawnEnemy() {
  const lvl = LEVELS[currentLevel];
  enemies.push({
    x: canvas.width + 20,
    y: GROUND_Y - 60,
    width: 46, height: 60,
    health: lvl.enemyHealth, maxHealth: lvl.enemyHealth,
    speed: lvl.enemySpeed + Math.random() * 0.4,
    hitCooldown: 0,
  });
}

function spawnPowerUp(x, y) {
  const types = ["health", "speed", "arrow"];
  const type = types[Math.floor(Math.random() * types.length)];
  powerUps.push({ x, y: y - 10, width: 26, height: 26, type, life: 600 });
}

// ---- Input ----
window.addEventListener("keydown", (e) => {
  keys[e.key.toLowerCase()] = true;
  if (e.key === " " && state === "playing") shootArrow();
  if (e.key.toLowerCase() === "h" && state === "playing") useAllyAbility();
  if (e.key.toLowerCase() === "p") togglePause();
});
window.addEventListener("keyup", (e) => { keys[e.key.toLowerCase()] = false; });

function togglePause() {
  if (state === "playing") { state = "paused"; showOnly("paused"); }
  else if (state === "paused") { state = "playing"; showOnly(null); }
}

function shootArrow() {
  if (player.shootCooldown > 0) return;
  arrows.push({
    x: player.x + player.width, y: player.y + 28,
    width: 26, height: 5, speed: 9,
  });
  player.shootCooldown = 16;
}

function useAllyAbility() {
  const lvl = LEVELS[currentLevel];
  if (!lvl.allyAbility || allyCooldown > 0) return;
  enemies.forEach((en) => (en.health -= 40));
  if (boss) boss.health -= 25;
  allyCooldown = 300; // frames (~5s at 60fps)
}

// ---- Update ----
function update() {
  if (state !== "playing") return;
  frame++;
  const lvl = LEVELS[currentLevel];

  if (player.shootCooldown > 0) player.shootCooldown--;
  if (player.hitCooldown > 0) player.hitCooldown--;
  if (allyCooldown > 0) allyCooldown--;

  // movement
  if (keys["arrowleft"] || keys["a"]) player.x -= player.speed;
  if (keys["arrowright"] || keys["d"]) player.x += player.speed;
  player.x = clamp(player.x, 0, canvas.width - player.width);

  // arrows
  arrows.forEach((a) => (a.x += a.speed));
  arrows = arrows.filter((a) => a.x < canvas.width);

  // spawn logic
  if (!lvl.isBoss) {
    spawnTimer++;
    if (waveRemainingToSpawn > 0 && spawnTimer >= lvl.spawnGap) {
      spawnEnemy();
      waveRemainingToSpawn--;
      spawnTimer = 0;
    }
  }

  // enemies
  enemies.forEach((en) => {
    if (en.hitCooldown > 0) en.hitCooldown--;
    const dist = en.x - (player.x + player.width);
    if (dist > 55) en.x -= en.speed;
    else if (collision(player, en) && en.hitCooldown <= 0 && player.hitCooldown <= 0) {
      player.health -= 8;
      player.hitCooldown = 40;
    }
  });

  // arrow-enemy collisions
  arrows.forEach((a) => {
    enemies.forEach((en) => {
      if (a._used || en.health <= 0) return;
      if (collision(a, en)) {
        en.health -= 12;
        a._used = true;
        en.hitCooldown = 10;
      }
    });
  });
  arrows = arrows.filter((a) => !a._used);

  // defeated enemies
  const survivors = [];
  enemies.forEach((en) => {
    if (en.health <= 0) {
      score += 10;
      if (Math.random() < 0.25) spawnPowerUp(en.x, en.y);
    } else survivors.push(en);
  });
  enemies = survivors;

  // power-ups
  powerUps.forEach((p) => (p.life--));
  powerUps = powerUps.filter((p) => p.life > 0);
  powerUps.forEach((p) => {
    if (collision(player, p)) {
      if (p.type === "health") player.health = Math.min(player.maxHealth, player.health + 25);
      if (p.type === "speed") { player.speed = 6; setTimeout(() => (player.speed = 4), 4000); }
      if (p.type === "arrow") player.shootCooldown = 0;
      p.life = 0;
      score += 5;
    }
  });
  powerUps = powerUps.filter((p) => p.life > 0);

  // boss logic
  if (boss) {
    boss.hitCooldown = Math.max(0, boss.hitCooldown - 1);
    boss.x += boss.speed * boss.dir;
    if (boss.x < 550 || boss.x > 760) boss.dir *= -1;

    if (boss.health < 400 && !boss.spawnFlagPhase2) {
      boss.phase = 2; boss.speed = 1.6; boss.spawnFlagPhase2 = true;
    }
    if (boss.health < 180 && !boss.spawnFlagPhase3) {
      boss.phase = 3; boss.speed = 2.2; boss.spawnFlagPhase3 = true;
    }
    // periodic minion spawn in later phases
    if (boss.phase >= 2 && frame % 240 === 0) spawnEnemy();

    arrows.forEach((a) => {
      if (!a._used && collision(a, boss)) {
        boss.health -= 10;
        a._used = true;
      }
    });
    arrows = arrows.filter((a) => !a._used);

    if (collision(player, boss) && boss.hitCooldown <= 0 && player.hitCooldown <= 0) {
      player.health -= 12 + boss.phase * 2;
      player.hitCooldown = 45;
      boss.hitCooldown = 45;
    }
    updateBossBar();

    if (boss.health <= 0) {
      score += 500;
      boss = null;
      onLevelClear();
    }
  }

  // level clear check (non-boss)
  if (!lvl.isBoss && waveRemainingToSpawn === 0 && enemies.length === 0) {
    onLevelClear();
  }

  if (player.health <= 0) {
    player.health = 0;
    state = "gameOver";
    el("gameOverText").textContent = "You were overwhelmed in " + lvl.name + ".";
    showOnly("gameOver");
  }

  updateHUD();
}

function onLevelClear() {
  if (state !== "playing") return;
  state = "levelComplete";
  el("levelCompleteText").textContent =
    "The " + LEVELS[currentLevel].name + " encounter has ended. Score: " + score;
  showOnly("levelComplete");
}

function updateHUD() {
  el("healthFill").style.width = (player.health / player.maxHealth) * 100 + "%";
  el("healthText").textContent = Math.max(0, Math.round(player.health)) + "/" + player.maxHealth;
  el("scoreText").textContent = score;
}
function updateBossBar() {
  if (!boss) return;
  el("bossFill").style.width = (boss.health / boss.maxHealth) * 100 + "%";
}

// ---- Draw ----
function draw() {
  const lvl = LEVELS[currentLevel] || LEVELS[0];
  ctx.fillStyle = lvl.bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = lvl.ground;
  ctx.fillRect(0, GROUND_Y, canvas.width, canvas.height - GROUND_Y);

  // player (Rama)
  ctx.fillStyle = "#d98c3a";
  ctx.fillRect(player.x, player.y, player.width, player.height);
  ctx.font = "28px serif";
  ctx.fillText("🏹", player.x + 10, player.y + 40);

  // arrows
  ctx.fillStyle = "#3b2a1a";
  arrows.forEach((a) => ctx.fillRect(a.x, a.y, a.width, a.height));

  // enemies
  enemies.forEach((en) => {
    ctx.fillStyle = "#5a2323";
    ctx.fillRect(en.x, en.y, en.width, en.height);
    ctx.fillStyle = "#222";
    ctx.fillRect(en.x, en.y - 10, en.width, 5);
    ctx.fillStyle = "#4caf50";
    ctx.fillRect(en.x, en.y - 10, en.width * (en.health / en.maxHealth), 5);
    ctx.font = "22px serif";
    ctx.fillText("👹", en.x + 8, en.y + 24);
  });

  // boss
  if (boss) {
    ctx.fillStyle = "#331111";
    ctx.fillRect(boss.x, boss.y, boss.width, boss.height);
    ctx.font = "60px serif";
    ctx.fillText("👺", boss.x + 10, boss.y + 60);
  }

  // power-ups
  powerUps.forEach((p) => {
    ctx.font = "22px serif";
    const icon = p.type === "health" ? "❤️" : p.type === "speed" ? "⚡" : "🏹";
    ctx.fillText(icon, p.x, p.y + 20);
  });
}

// ---- Main loop ----
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

showOnly("menu");
draw();
loop();
